/* PATCHED 14: email is exclusively the published Instagram commercial contact.
 * Each profile is classified as found, empty, hidden, omitted or personal
 * account, kept apart from access failures. No network calls, login/recovery
 * fields, viewer traversal, inferred contacts, or bio/link fallback for email.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.IGPublicContacts = api;
})(typeof window !== "undefined" ? window : globalThis, function () {
  "use strict";
  var own = Object.prototype.hasOwnProperty;
  // Top-level fields only: no live response has shown a nested contact block.
  var emailFields = ["public_email", "business_email"];
  // PATCHED 10-13 block names remain readable for phones and saved rows only.
  var contactBlocks = ["professional_contact_info", "professional_metadata", "public_contact_info", "business_contact_info"];
  var phoneFields = ["contact_phone_number", "public_phone_number", "business_phone_number"];
  var statusText = {
    found: "Contato público do Instagram",
    empty: "Campo comercial vazio",
    not_delivered: "E-mail não entregue pela consulta web (perfil anuncia contato)",
    hidden: "Contato oculto pelo perfil",
    omitted: "Campo omitido pela consulta",
    not_professional: "Conta pessoal (sem botão Contato)",
    invalid: "Formato de e-mail inválido",
    profile_unavailable: "Perfil indisponível",
    identity_mismatch: "Perfil divergente (dados não aplicados)",
    // Statuses saved by PATCHED 12-13 rows.
    not_published: "Sem e-mail comercial publicado",
    not_returned: "Não retornado pelo Instagram",
    source_not_verified: "Contato comercial não verificado"
  };
  var failureTexts = {
    rate_limit: "Falha de acesso: limite do Instagram (HTTP 429)",
    cooldown: "Aguardando o fim da pausa do Instagram",
    redirect: "Falha de acesso: redirecionamento (login ou verificação)",
    access: "Falha de acesso",
    network: "Falha de acesso: rede ou tempo esgotado",
    invalid_response: "Falha de acesso: resposta não JSON",
    unexpected_response: "Falha de acesso: resposta em formato desconhecido",
    unsupported: "Consulta sem campo comercial (fila parada)",
    request: "Falha ao processar a consulta"
  };

  function text(value) {
    return typeof value === "string" || typeof value === "number" ? String(value).trim() : "";
  }
  function at(value, path) {
    return path.split(".").reduce(function (obj, key) {
      return obj && typeof obj === "object" && own.call(obj, key) ? obj[key] : undefined;
    }, value);
  }
  function validEmail(value) {
    var s = text(value).replace(/^mailto:/i, "").split("?")[0];
    var local = s.split("@")[0];
    // Retain plus addressing; require a complete address rather than an @mention.
    var labels = (s.split("@")[1] || "").split(".");
    return s.length <= 254 && local.length <= 64 && labels.every(function (label) { return label.length <= 63; }) && !/^\.|\.$|\.\./.test(local) && /^[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9](?:[A-Z0-9-]*[A-Z0-9])?(?:\.[A-Z0-9](?:[A-Z0-9-]*[A-Z0-9])?)+$/i.test(s) ? s : "";
  }
  function hidden(value) { return value === false || value === 0 || value === "false" || value === "0"; }
  function published(value) { return value === true || value === 1 || value === "true" || value === "1"; }
  function profileType(user) {
    if (!user || typeof user !== "object") return "unknown";
    var accountType = Number(user.account_type);
    if (accountType === 2 || published(user.is_business_account) || published(user.is_business)) return "business";
    if (accountType === 3) return "creator";
    if (published(user.is_professional_account)) return hidden(user.is_business_account) ? "creator" : "professional";
    if (accountType === 1 || hidden(user.is_professional_account)) return "personal";
    return "unknown";
  }
  // Owner advertises a Contact button (CALL/TEXT/...), "UNKNOWN" means none.
  function advertisedContact(user) {
    var method = text(user.business_contact_method).toUpperCase();
    return !!method && method !== "UNKNOWN" && method !== "NONE";
  }
  function valueState(user, field) {
    if (!own.call(user, field)) return "absent";
    var value = user[field];
    if (value === null || value === undefined) return "null";
    return text(value) ? "present" : "empty";
  }
  // absent = key not returned; null/empty = returned without a value.
  function fieldState(user, field) {
    if (!own.call(user, field)) return "absent";
    var value = user[field];
    if (value === null || value === undefined) return "null";
    if (value === false || (typeof value === "string" && !value.trim())) return "empty";
    if (typeof value !== "string" && typeof value !== "number") return "invalid";
    return validEmail(value) ? "valid" : "invalid";
  }
  function classifyEmail(user) {
    user = user && typeof user === "object" ? user : {};
    var keys = {}, returned = false, invalid = false, email = "", source = "";
    emailFields.forEach(function (field) {
      var state = keys[field] = fieldState(user, field);
      if (state !== "absent") returned = true;
      if (state === "invalid") invalid = true;
      if (state === "valid" && !email) { email = validEmail(user[field]); source = field; }
    });
    var type = profileType(user), status, displayed = published(user.should_show_public_contacts);
    var webShape = keys.business_email !== "absent" && keys.public_email !== "valid";
    keys.business_phone_number = valueState(user, "business_phone_number");
    // Web captures since 2022 return business_* as null even for profiles whose
    // app shows a Contact button: with the display flag on, null means "not
    // delivered by this route", not "no email published".
    var withheld = type !== "personal" && displayed && advertisedContact(user) && !email &&
      keys.business_email !== "absent" && keys.business_email !== "valid" &&
      (keys.business_phone_number === "null" || keys.business_phone_number === "empty");
    // Personal accounts have no Contact button; a hidden flag wins over any value.
    if (type === "personal") status = "not_professional";
    else if (hidden(user.should_show_public_contacts)) status = "hidden";
    else if (email) status = "found";
    else if (invalid) status = "invalid";
    // Only a profile that actually advertises a contact method is reported as
    // withheld; without it, an empty field is just an empty field.
    else if (returned) status = withheld ? "not_delivered" : "empty";
    else status = "omitted";
    return { status: status, email: status === "found" ? email : "", source: status === "found" ? source : "",
      profileType: type, fieldReturned: returned, keys: keys, withheld: withheld };
  }
  function commercialEmail(row) {
    if (!row || typeof row !== "object") return "";
    // Old bio/site results and unmarked legacy rows must not become button emails.
    var source = text(row.emailSource), trusted = emailFields.indexOf(source) >= 0;
    contactBlocks.forEach(function (key) {
      if (source === key || source === key + ".public_email" || source === key + ".business_email" || source === key + ".email") trusted = true;
    });
    return trusted && (row.emailKind === "commercial_contact" || Number(row.contactParserVersion) >= 10) ? validEmail(row.email) : "";
  }
  function failureText(failure) {
    if (!failure || typeof failure !== "object") return "";
    var message = failureTexts[failure.code] || failureTexts.access;
    if (failure.code === "access" && failure.status) message += " (HTTP " + failure.status + ")";
    return message;
  }
  function emailStatusText(row) {
    if (commercialEmail(row)) return statusText.found;
    if (row && row.loaded && row.detailLoaded === false) return failureText(row.contactFailure) || "Aguardando consulta";
    if (row && (row.emailStatus === "source_not_verified" || (row.email && !commercialEmail(row)))) return statusText.source_not_verified;
    var status = row && row.emailStatus;
    return status && status !== "found" && own.call(statusText, status) ? statusText[status] : statusText.not_returned;
  }
  function commercialRow(row) {
    var copy = Object.assign({}, row), email = commercialEmail(row);
    if (copy.email && !email) copy.emailStatus = "source_not_verified";
    copy.email = email;
    return copy;
  }
  function emailInText(value) {
    var matches = text(value).match(/[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9-]+(?:\.[A-Z0-9-]+)+/ig) || [];
    for (var i = 0; i < matches.length; i++) {
      var result = validEmail(matches[i].replace(/[.,;:!?]+$/, ""));
      if (result) return result;
    }
    return "";
  }
  function validPhone(value, countryCode) {
    var s = text(value).replace(/^tel:/i, "").split("?")[0].trim();
    if (!s || !/^\+?[\d\s().-]+$/.test(s)) return "";
    var digits = s.replace(/\D/g, "");
    if (digits.length < 8 || digits.length > 15 || /^(\d)\1+$/.test(digits)) return "";
    var international = s.charAt(0) === "+";
    if (!international && digits.indexOf("00") === 0 && digits.length >= 10) {
      digits = digits.slice(2);
      international = true;
    }
    var country = text(countryCode).replace(/^\+/, "");
    if (!international && /^[1-9]\d{0,2}$/.test(country)) {
      // Explicit full international numbers may already contain the country code.
      if (!(digits.indexOf(country) === 0 && digits.length >= country.length + 10)) digits = country + digits;
      international = true;
    }
    if (digits.length > 15 || (international && digits.charAt(0) === "0")) return "";
    return (international ? "+" : "") + digits;
  }
  function phoneInText(value) {
    var s = text(value), re = /\+?\d[\d \t().-]{6,}\d/g, match;
    while ((match = re.exec(s))) {
      var before = s.slice(Math.max(0, match.index - 40), match.index);
      var after = s.slice(match.index + match[0].length, match.index + match[0].length + 1);
      var previous = s.charAt(match.index - 1);
      // Reject IDs, years, dates, quantities, and digits inside handles/URLs.
      if (/[\w@/#]/.test(previous) || /[\w@/]/.test(after)) continue;
      if (/(?:\b(?:CRM|RQE|CNPJ|CPF|CEP|registro|licen[çc]a|nasc(?:imento)?|born|desde|since|posts?|followers?|seguidores?)\b)[^\n\d]{0,18}$/i.test(before)) continue;
      var digits = match[0].replace(/\D/g, "");
      var labeled = /(?:whats(?:app)?|wpp|telefone|fone|tel\.?|phone|contato|contact|booking|reservas?|☎|📞)[^\n\d]{0,18}$/i.test(before);
      var international = match[0].charAt(0) === "+";
      var areaCode = /^\d{2,3}\)\s*\d/.test(match[0]) && previous === "(";
      var formatted = /^\d{2,3}[ \t.-]+\d{4,5}[ \t.-]+\d{4}$/.test(match[0]);
      if (!(labeled || international || areaCode || formatted)) continue;
      var result = validPhone(match[0]);
      if (result) return result;
    }
    return "";
  }
  function profileFromResponse(response, expectedId, expectedUsername) {
    // Known profile envelopes only. Never inspect data.viewer or suggested users.
    var paths = ["data.data.user", "data.user", "user",
      "data.data.xdt_api__v1__users__web_profile_info.user",
      "data.xdt_api__v1__users__web_profile_info.user",
      "data.data.xdt_api__v1__users__web_profile_info",
      "data.xdt_api__v1__users__web_profile_info"];
    for (var i = 0; i < paths.length; i++) {
      var user = at(response, paths[i]);
      if (!user || typeof user !== "object" || Array.isArray(user)) continue;
      var id = text(user.pk || user.id), username = text(user.username);
      if (!id && !username) continue;
      if (expectedId && id && id !== text(expectedId)) continue;
      if (expectedUsername && username && username.toLowerCase() !== text(expectedUsername).toLowerCase()) continue;
      return user;
    }
    return null;
  }
  function linkContacts(value) {
    var result = { email: "", phone: "" }, raw = text(value);
    if (!raw) return result;
    try {
      var url = new URL(raw);
      if (url.hostname === "l.instagram.com" && url.searchParams.has("u")) url = new URL(url.searchParams.get("u"));
      if (url.protocol === "mailto:") result.email = validEmail(decodeURIComponent(url.pathname));
      else if (url.protocol === "tel:") result.phone = validPhone(decodeURIComponent(url.pathname));
      else if (url.protocol === "https:" || url.protocol === "http:") {
        if (url.hostname === "wa.me") result.phone = validPhone("+" + url.pathname.replace(/^\//, ""));
        else if (url.hostname === "api.whatsapp.com" || url.hostname === "web.whatsapp.com") {
          if (url.pathname === "/send" || url.pathname === "/send/") result.phone = validPhone("+" + (url.searchParams.get("phone") || ""));
        }
      }
    } catch (err) { /* malformed profile link: no contact */ }
    return result;
  }
  function extract(user) {
    user = user && typeof user === "object" ? user : {};
    var bio = text(user.biography) || text(at(user, "biography_with_entities.raw_text"));
    var contact = classifyEmail(user);
    var visible = !hidden(user.should_show_public_contacts);
    var result = { email: contact.email, phone: "", emailSource: contact.source, phoneSource: "", biography: bio,
      emailStatus: contact.status, phoneStatus: visible ? "not_returned" : "not_published",
      profileType: contact.profileType, emailFieldReturned: contact.fieldReturned, emailKeys: contact.keys,
      contactWithheld: contact.withheld };
    if (visible) {
      phoneFields.forEach(function (field) {
        if (own.call(user, field)) result.phoneStatus = "not_published";
        var value = validPhone(user[field], user.public_phone_country_code);
        if (!result.phone && value) { result.phone = value; result.phoneSource = field; }
      });
      contactBlocks.forEach(function (key) {
        var info = user[key];
        if (!info || typeof info !== "object" || Array.isArray(info)) return;
        if (hidden(info.is_public) || hidden(info.should_show_public_contacts)) return;
        // Generic phone_number is accepted only with explicit publication.
        var markedPublic = key === "public_contact_info" || published(info.is_public) || published(info.should_show_public_contacts) || published(user.should_show_public_contacts);
        var phone = validPhone(info.contact_phone_number || info.public_phone_number || info.business_phone_number || (markedPublic ? info.phone_number : ""), info.country_code || user.public_phone_country_code);
        if (!result.phone && phone) { result.phone = phone; result.phoneSource = key; }
      });
    }
    // Keep the existing public phone parser; email never falls back to bio or links.
    if (!result.phone) { result.phone = phoneInText(bio); if (result.phone) result.phoneSource = "biography"; }
    var links = [user.external_url, user.external_lynx_url, user.external_url_linkshimmed];
    (Array.isArray(user.bio_links) ? user.bio_links : []).forEach(function (link) {
      if (link && typeof link === "object") links.push(link.url, link.lynx_url);
    });
    // Bio may contain a direct WhatsApp, mailto or tel link as plain text.
    links = links.concat(bio.match(/(?:https?:\/\/[^\s<>]+|mailto:[^\s<>]+|tel:\+?[\d().-]+)/ig) || []);
    links.forEach(function (link) {
      var contacts = linkContacts(link);
      if (!result.phone && contacts.phone) { result.phone = contacts.phone; result.phoneSource = "profile_link"; }
    });
    if (result.email) result.emailKind = "commercial_contact";
    if (result.phone) result.phoneStatus = "found";
    return result;
  }
  function number(user, field, alternate) {
    var value = user[field];
    if (value === undefined || value === null) value = at(user, alternate);
    if (typeof value === "string" && /^\d+$/.test(value)) value = Number(value);
    return typeof value === "number" && isFinite(value) && value >= 0 ? value : 0;
  }
  function toDetailResponse(user, username) {
    var contacts = extract(user), address = user.business_address_json || user.business_address || {};
    try { if (typeof address === "string") address = JSON.parse(address); } catch (err) { address = {}; }
    if (!address || typeof address !== "object") address = {};
    return { data: { status: "ok", user: {
      profile_pic_url: text(user.profile_pic_url_hd) || text(at(user, "hd_profile_pic_url_info.url")) || text(user.profile_pic_url),
      username: text(user.username) || text(username), full_name: text(user.full_name),
      follower_count: number(user, "follower_count", "edge_followed_by.count"),
      following_count: number(user, "following_count", "edge_follow.count"),
      media_count: number(user, "media_count", "edge_owner_to_timeline_media.count"),
      public_email: contacts.email, contact_phone_number: contacts.phone,
      public_phone_number: "", public_phone_country_code: "",
      city_name: text(user.city_name) || text(address.city_name || address.locality || address.city) || text(at(user, "professional_contact_info.city_name")),
      address_street: text(user.address_street) || text(address.street_address || address.address_street || address.address) || text(at(user, "professional_contact_info.address_street")),
      is_private: !!user.is_private, is_verified: !!user.is_verified,
      is_business: !!(user.is_business || user.is_business_account || user.is_professional_account),
      external_url: text(user.external_url) || text(user.external_url_linkshimmed), biography: contacts.biography
    } }, publicContactResult: contacts };
  }
  return { extract: extract, classifyEmail: classifyEmail, profileType: profileType, emailFields: emailFields.slice(),
    profileFromResponse: profileFromResponse, toDetailResponse: toDetailResponse,
    validEmail: validEmail, validPhone: validPhone, emailInText: emailInText, phoneInText: phoneInText, linkContacts: linkContacts,
    commercialEmail: commercialEmail, commercialRow: commercialRow, emailStatusText: emailStatusText,
    failureText: failureText, statusText: statusText };
});
