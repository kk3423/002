/* Serial Instagram request spacing; no network operations. */
(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.IGRequestPacing = api;
})(typeof window !== "undefined" ? window : globalThis, function () {
  "use strict";
  function intervals(value, type) {
    var range = Array.isArray(value) ? value.slice(0, 2) : [15, 30];
    if (type === 4 && Number(range[0]) === 15 && Number(range[1]) === 30) range = [10, 15];
    var low = Math.max(10, Number(range[0]) || 10);
    return [low, Math.max(low, Number(range[1]) || 15)];
  }
  return { intervals: intervals };
});
