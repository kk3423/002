/* PATCHED 14-15.3: one ordinary web_profile_info request per profile, serial and
 * fail closed. Every real response is summarised (field names, profile flags,
 * masked email) so the commercial-contact field can be verified, not guessed.
 * A live public commercial contact has not yet been confirmed.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.IGCommercialProfileReader = api;
})(typeof window !== "undefined" ? window : globalThis, function () {
  "use strict";
  var endpoint = "instagram_web_profile_info";
  var cooldownKey = "ig_contact_cooldown_until";
  var schemaKey = "ig_commercial_contact_schema_v14";
  var evidenceKey = "ig_commercial_contact_evidence_v14";
  var lastStartKey = "ig_commercial_web_last_start";
  // Adaptive spacing between profile requests, shared by every dashboard.
  var pacingKey = "ig_contact_pacing";
  var baseSpacing = 10000, maxSpacing = 120000;
  // Answered profiles, kept across extractions so the same profile is not asked twice.
  var profileCacheKey = "ig_contact_profile_cache_v15";
  var cacheTtl = 14 * 864e5, missingTtl = 3 * 864e5, cacheLimit = 3000;
  var lockName = "ig-commercial-profile-read";
  // Every read-modify-write of the shared pause goes through this lock, in the reader
  // and in the dashboard, so two tabs can never shorten each other's pause.
  var cooldownLock = "ig-contact-cooldown";
  var own = Object.prototype.hasOwnProperty;
  var professionalTypes = ["business", "creator", "professional"];
  // The omission/withheld limits are kept only so older saved schemas still parse.
  var omittedProfessionalLimit = 3, withheldProfessionalLimit = 3, refusedLimit = 2, evidenceLimit = 20, listLimit = 10;
  var flagFields = ["account_type", "is_business_account", "is_professional_account", "is_business",
    "should_show_public_contacts", "business_contact_method", "is_private"];

  function retryUntil(value, now) {
    var raw = String(value == null ? "" : value).trim();
    if (/^\d+(?:\.\d+)?$/.test(raw)) return now + Math.max(10, Number(raw)) * 1000;
    var date = Date.parse(raw);
    return Number.isFinite(date) && date > now ? date : now + 3600000;
  }
  // Merge a new pause into the saved one (never shorter), under the shared lock, with one retry.
  function saveCooldown(storage, locks, until, wait) {
    var write = function () {
      return Promise.resolve(storage.get(cooldownKey)).then(function (latest) {
        var value = Math.max(Number(latest && latest[cooldownKey]) || 0, Number(until) || 0);
        return Promise.resolve(storage.set({ [cooldownKey]: value })).then(function () { return value; });
      });
    };
    var attempt = function () { return locks && typeof locks.request === "function" ? locks.request(cooldownLock, write) : write(); };
    return attempt().catch(function () {
      return Promise.resolve(wait ? wait(1000) : null).then(attempt);
    });
  }
  function stopped(message, code, response) {
    var error = new Error(message);
    error.commercialRequestStopped = true;
    error.stopCode = code;
    if (response) error.response = response;
    return error;
  }
  function maskEmail(value) {
    var s = String(value || ""), at = s.indexOf("@");
    return at > 0 ? s.charAt(0) + "***" + s.slice(at) : "";
  }
  function readSchema(value) {
    var schema = { endpoint: endpoint, keysPresent: 0, keysPresentUsers: [], omittedProfessional: [], omittedOther: 0,
      found: 0, foundUsers: [], withheldProfessional: [], responses: 0, profiles: 0, refusals: 0, lastRefusalAt: 0, firstFound: null, updatedAt: 0 };
    if (!value || typeof value !== "object" || value.endpoint !== endpoint) return schema;
    schema.keysPresent = Number(value.keysPresent) || 0;
    schema.omittedOther = Number(value.omittedOther) || 0;
    schema.found = Number(value.found) || 0;
    // Older PATCHED 14 schemas have no counter: infer a lower bound from the
    // per-profile tallies so earlier answers are not read as "never answered".
    schema.responses = Number(value.responses) ||
      (schema.keysPresent + schema.omittedOther + (Array.isArray(value.omittedProfessional) ? value.omittedProfessional.length : 0));
    schema.profiles = Number(value.profiles) || 0;
    schema.refusals = Number(value.refusals) || 0;
    schema.lastRefusalAt = Number(value.lastRefusalAt) || 0;
    if (value.firstFound && typeof value.firstFound === "object") {
      schema.firstFound = { at: Number(value.firstFound.at) || 0, username: String(value.firstFound.username || ""),
        email: String(value.firstFound.email || ""), probe: !!value.firstFound.probe };
    }
    schema.updatedAt = Number(value.updatedAt) || 0;
    ["keysPresentUsers", "omittedProfessional", "foundUsers", "withheldProfessional"].forEach(function (key) {
      schema[key] = Array.isArray(value[key]) ? value[key].slice(-listLimit) : [];
    });
    return schema;
  }
  // PATCHED 15.3: profiles without an email never stop the queue (each row keeps its own
  // status). Only access failures (429, 403, login...) pause it. Kept for compatibility.
  function blockReason() { return ""; }
  // Diagnostic only: repeated refusals with no profile answer at all.
  function routeRefusing(value) {
    var schema = readSchema(value);
    return schema.responses === 0 && schema.refusals >= refusedLimit;
  }
  function unsupported(value) { return !!blockReason(value); }
  function valueType(value) {
    if (value === null || value === undefined) return "null";
    if (typeof value === "string") return value.trim() ? "texto" : "vazio";
    if (Array.isArray(value)) return "lista";
    return typeof value === "object" ? "objeto" : typeof value;
  }
  // Email-related paths anywhere in a response: names and value types only, never values.
  function emailPaths(body) {
    var out = [], seen = 0;
    (function walk(node, path, depth) {
      if (!node || typeof node !== "object" || depth > 8 || seen > 4000) return;
      Object.keys(node).forEach(function (key) {
        seen++;
        var child = node[key], here = path ? path + "." + key : key;
        if (/e-?mail|contact_method|should_show_public_contacts/i.test(key) && out.length < 40) out.push(here + "=" + valueType(child));
        if (child && typeof child === "object") walk(Array.isArray(child) ? child[0] : child, Array.isArray(child) ? here + "[]" : here, depth + 1);
      });
    })(body, "", 0);
    return out;
  }
  function remember(list, username) {
    return list.indexOf(username) >= 0 ? list : list.concat(username).slice(-listLimit);
  }
  function locate(body) {
    // web_profile_info envelope, as in the extension's ApiProfileInfo config: { data: { user } }.
    var data = body && typeof body === "object" ? body.data : null;
    if (!data || typeof data !== "object" || !own.call(data, "user")) return { known: false, user: null };
    var user = data.user;
    return { known: true, user: user && typeof user === "object" && !Array.isArray(user) ? user : null };
  }
  function create(deps) {
    var cache = new Map();
    function readPacing(saved) {
      var p = saved && saved[pacingKey] && typeof saved[pacingKey] === "object" ? saved[pacingKey] : {};
      var spacing = Math.min(maxSpacing, Math.max(baseSpacing, Number(p.spacing) || baseSpacing));
      return { spacing: spacing, okStreak: Math.max(0, Number(p.okStreak) || 0) };
    }
    // Refusal: double the spacing (up to 2 min) for when the pause ends. Five answered
    // profiles in a row bring it 20% closer to the 10 s base.
    function updatePacing(ok) {
      return Promise.resolve(deps.storage.get(pacingKey)).then(function (saved) {
        var p = readPacing(saved);
        if (ok) {
          p.okStreak += 1;
          if (p.okStreak >= 5) { p.spacing = Math.max(baseSpacing, Math.round(p.spacing * 0.8)); p.okStreak = 0; }
        } else { p.spacing = Math.min(maxSpacing, p.spacing * 2); p.okStreak = 0; }
        return deps.storage.set({ [pacingKey]: p });
      }).catch(function () {});
    }
    function cachedProfile(saved, username, userId) {
      var all = saved && saved[profileCacheKey] && typeof saved[profileCacheKey] === "object" ? saved[profileCacheKey] : {};
      var hit = all[endpoint + ":" + username];
      if (!hit || !hit.result || typeof hit.result !== "object") return null;
      var ttl = hit.result.contactSkip ? missingTtl : cacheTtl;
      if (!(Number(hit.at) > deps.now() - ttl)) return null;
      // A username can move to another account: only the same id may reuse it.
      if (userId && hit.userId && hit.userId !== userId) return null;
      return hit.result;
    }
    function storeProfile(username, userId, result) {
      if (!result || result.contactOutcome === "identity_mismatch") return Promise.resolve();
      return Promise.resolve(deps.storage.get(profileCacheKey)).then(function (saved) {
        var all = saved && saved[profileCacheKey] && typeof saved[profileCacheKey] === "object" ? saved[profileCacheKey] : {};
        all[endpoint + ":" + username] = { at: deps.now(), userId: String(result.contactUserId || userId || ""), result: result };
        var keys = Object.keys(all);
        if (keys.length > cacheLimit) keys.sort(function (a, b) { return (all[a].at || 0) - (all[b].at || 0); })
          .slice(0, keys.length - cacheLimit).forEach(function (k) { delete all[k]; });
        return deps.storage.set({ [profileCacheKey]: all });
      }).catch(function () { /* the cache must never change the collection result */ });
    }
    // Only the saved 429 pause closes the queue; a profile without an email never does.
    function assertOpen(saved) {
      if (Number(saved[cooldownKey]) > deps.now()) {
        var cooldown = stopped("O Instagram está em pausa. Aguarde o horário indicado.", "cooldown");
        cooldown.cooldownUntil = Number(saved[cooldownKey]);
        throw cooldown;
      }
    }
    function record(entry) {
      return Promise.resolve().then(function () { return deps.storage.get(evidenceKey); }).then(function (saved) {
        var list = saved && Array.isArray(saved[evidenceKey]) ? saved[evidenceKey] : [];
        return deps.storage.set({ [evidenceKey]: [entry].concat(list).slice(0, evidenceLimit) });
      }).catch(function () { /* diagnostics must never change the collection result */ });
    }
    function updateSchema(username, contact, probe) {
      return deps.storage.get(schemaKey).then(function (saved) {
        var schema = readSchema(saved[schemaKey]);
        if (contact.emailStatus === "found") {
          schema.found += 1;
          schema.foundUsers = remember(schema.foundUsers, username);
          if (!schema.firstFound) schema.firstFound = { at: deps.now(), username: username, email: maskEmail(contact.email), probe: !!probe };
        }
        if (contact.emailFieldReturned) {
          schema.keysPresent += 1;
          schema.keysPresentUsers = remember(schema.keysPresentUsers, username);
        } else if (contact.emailStatus === "omitted" && professionalTypes.indexOf(contact.profileType) >= 0) {
          schema.omittedProfessional = remember(schema.omittedProfessional, username);
        } else {
          schema.omittedOther += 1;
        }
        schema.updatedAt = deps.now();
        return deps.storage.set({ [schemaKey]: schema }).then(function () { return schema; });
      });
    }
    // Route-level bookkeeping of real HTTP outcomes, independent of the profile.
    function noteOutcome(kind) {
      return deps.storage.get(schemaKey).then(function (saved) {
        var schema = readSchema(saved[schemaKey]);
        if (kind === "response" || kind === "profile") {
          schema.responses += 1;
          if (kind === "profile") schema.profiles += 1;
          schema.refusals = 0;
        }
        else { schema.refusals += 1; schema.lastRefusalAt = deps.now(); }
        schema.updatedAt = deps.now();
        return deps.storage.set({ [schemaKey]: schema }).then(function () { return schema; });
      });
    }
    function skip(outcome, entry) {
      entry.outcome = outcome;
      return { contactSkip: true, contactOutcome: outcome, contactEndpoint: endpoint };
    }
    async function fetchProfile(username, userId, entry) {
      var controller = new AbortController();
      var timer = setTimeout(function () { controller.abort(); }, 30000);
      var response, raw;
      try {
        try {
          response = await deps.fetch("https://www.instagram.com/api/v1/users/web_profile_info/?username=" + encodeURIComponent(username), {
            method: "GET", credentials: "include", redirect: "manual", cache: "no-store", signal: controller.signal,
            headers: { Accept: "application/json", "X-IG-App-ID": "936619743392459", "X-Requested-With": "XMLHttpRequest" }
          });
        } catch (err) {
          entry.outcome = "network";
          throw stopped("Falha de rede ou tempo esgotado na consulta de contato. Coleta pausada, sem nova tentativa automática.", "network");
        }
        entry.http = response.status;
        // Not followed: a login or checkpoint redirect is an access failure.
        if (response.type === "opaqueredirect" || (response.status >= 300 && response.status < 400)) {
          entry.outcome = "redirect";
          throw stopped("O Instagram redirecionou a consulta (login ou verificação). Coleta pausada, sem nova tentativa automática.", "redirect", { status: response.status });
        }
        if (response.status === 429) {
          entry.retryAfter = response.headers.get("retry-after");
          var until = retryUntil(entry.retryAfter, deps.now());
          // Storage may fail (invalidated context); the pause must still be reported.
          try {
            until = await saveCooldown(deps.storage, deps.locks, until, deps.wait);
            entry.cooldownSaved = true;
          } catch (storageError) { entry.cooldownSaved = false; }
          entry.outcome = "rate_limit";
          entry.cooldownUntil = until;
          var limited = stopped("O Instagram limitou as consultas (HTTP 429). Coleta pausada até o horário indicado, sem nova tentativa automática.", "rate_limit", {
            status: 429, headers: { "retry-after": new Date(until).toUTCString() }
          });
          limited.cooldownUntil = until;
          throw limited;
        }
        try { raw = await response.text(); } catch (err) {
          entry.outcome = "network";
          throw stopped("Falha de rede ou tempo esgotado na consulta de contato. Coleta pausada, sem nova tentativa automática.", "network");
        }
      } finally { clearTimeout(timer); }
      var body = null;
      try { body = JSON.parse(raw); } catch (err) { body = null; }
      if (body && typeof body === "object") entry.emailPaths = emailPaths(body);
      // Instagram's text ends up in HTML notifications: keep it inert and short.
      var message = body && typeof body === "object" && typeof body.message === "string"
        ? body.message.replace(/[<>&"']/g, " ").replace(/\s+/g, " ").trim().slice(0, 120) : "";
      if (message) entry.message = message;
      if (response.status === 404) {
        entry.envelope = true;
        return skip("profile_unavailable", entry);
      }
      if (!response.ok) {
        entry.outcome = "access";
        throw stopped("O Instagram recusou a consulta de contato (HTTP " + response.status + (message ? ": " + message : "") + "). Coleta pausada, sem nova tentativa automática.", "access", { status: response.status });
      }
      if (!body || typeof body !== "object") {
        entry.outcome = "invalid_response";
        throw stopped("O Instagram devolveu uma página em vez de dados (possível login ou verificação). Coleta pausada, sem nova tentativa automática.", "invalid_response", { status: response.status });
      }
      if (body.status === "fail" || body.require_login || (Array.isArray(body.errors) && body.errors.length)) {
        entry.outcome = "access";
        throw stopped("O Instagram não autorizou a consulta de perfil" + (message ? " (" + message + ")" : "") + ". Coleta pausada, sem nova tentativa automática.", "access", { status: response.status });
      }
      var located = locate(body);
      entry.envelope = located.known;
      entry.profilePayload = !!located.user;
      if (!located.known) {
        entry.outcome = "unexpected_response";
        throw stopped("A resposta do Instagram veio num formato desconhecido. Coleta pausada, sem nova tentativa automática.", "unexpected_response", { status: response.status });
      }
      // Missing or renamed profiles are per-row results, not session failures.
      if (!located.user) return skip("profile_unavailable", entry);
      var user = located.user;
      var returnedName = String(user.username || "").toLowerCase(), returnedId = String(user.pk || user.id || "");
      if (returnedName !== username || (userId && returnedId && returnedId !== userId)) {
        entry.returnedUsername = returnedName.slice(0, 40);
        var mismatch = skip("identity_mismatch", entry);
        mismatch.contactUserId = returnedId;
        return mismatch;
      }
      var detail = deps.contacts.toDetailResponse(user, username), contact = detail.publicContactResult, flags = {};
      flagFields.forEach(function (key) { if (own.call(user, key)) flags[key] = user[key]; });
      entry.outcome = contact.emailStatus;
      entry.profileType = contact.profileType;
      entry.keys = contact.emailKeys;
      entry.flags = flags;
      entry.userKeys = Object.keys(user).sort().slice(0, 300);
      entry.email = maskEmail(contact.email);
      entry.withheld = !!contact.contactWithheld;
      detail.contactEndpoint = endpoint;
      detail.contactUserId = returnedId;
      detail.contactOutcome = contact.emailStatus;
      detail.commercialContactFieldReturned = contact.emailFieldReturned;
      // Per-row diagnostics: field states and visibility flags, never values.
      detail.contactKeys = contact.emailKeys;
      detail.contactFlags = flags;
      return detail;
    }
    function decided(result, schemaValue, fromCache) {
      var copy = Object.assign({}, result);
      copy.commercialSchemaUnsupported = unsupported(schemaValue);
      copy.commercialSchema = readSchema(schemaValue);
      if (fromCache) copy.fromCache = true;
      return copy;
    }
    return async function read(userId, username, isCurrent, options) {
      var probe = !!(options && options.probe);
      username = String(username || "").trim().replace(/^@/, "").toLowerCase();
      userId = String(userId || "");
      if (!/^[a-z0-9_](?:[a-z0-9_.]{0,28}[a-z0-9_])?$/.test(username)) {
        throw stopped("Nome de perfil inválido. A consulta foi interrompida.", "identity");
      }
      if (!deps.locks || typeof deps.locks.request !== "function") {
        throw stopped("Não foi possível controlar a fila de consultas. Coleta pausada.", "lock");
      }
      var active = function () { return !isCurrent || isCurrent(); };
      // Keyed by username only: the queue and the manual check must share one
      // response, so the same profile is never requested twice in a page.
      var cacheKey = username;
      var usable = function (saved) {
        if (!saved) return false;
        // A mismatch says "this username did not answer for that id": reuse it
        // only for the same request, never for the id that came back.
        if (saved.contactOutcome === "identity_mismatch") return saved.requestedUserId === userId;
        return !userId || !saved.contactUserId || saved.contactUserId === userId;
      };
      return deps.locks.request(lockName, async function () {
        try {
          if (!active()) throw stopped("Consulta cancelada.", "cancelled");
          var saved = await deps.storage.get([cooldownKey, schemaKey, lastStartKey, pacingKey, profileCacheKey]);
          assertOpen(saved);
          if (cache.has(cacheKey) && usable(cache.get(cacheKey))) return decided(cache.get(cacheKey), saved[schemaKey], true);
          // Answered before (this or another extraction): no new request for the same profile.
          var stored = probe ? null : cachedProfile(saved, username, userId);
          if (stored) { cache.set(cacheKey, stored); return decided(stored, saved[schemaKey], true); }
          var delay = Math.max(0, Number(saved[lastStartKey]) + readPacing(saved).spacing - deps.now());
          if (delay) await deps.wait(delay);
          // Another dashboard can save a cooldown or a decision while this reader waits.
          saved = await deps.storage.get([cooldownKey, schemaKey]);
          assertOpen(saved);
          if (!active()) throw stopped("Consulta cancelada.", "cancelled");
          await deps.storage.set({ [lastStartKey]: deps.now() });
          if (!active()) throw stopped("Consulta cancelada.", "cancelled");
          var entry = { at: deps.now(), endpoint: endpoint, username: username, probe: probe, http: null, outcome: "" };
          var result;
          try { result = await fetchProfile(username, userId, entry); }
          catch (failure) {
            var refusal = failure && (failure.stopCode === "rate_limit" ||
              (failure.stopCode === "access" && failure.response && failure.response.status === 400));
            if (refusal) {
              await updatePacing(false);
              var after = await noteOutcome("refusal");
              // Diagnostic signal only: the pause and the manual restart are unchanged.
              if (routeRefusing(after)) {
                failure.routeRefusing = true;
                failure.refusalCount = after.refusals;
              }
            }
            throw failure;
          }
          finally { await record(entry); }
          // 404 proves the route answers; only a parsed user object is a profile.
          if (entry.envelope) { await noteOutcome(entry.profilePayload ? "profile" : "response"); await updatePacing(true); }
          var schemaValue = saved[schemaKey];
          if (!result.contactSkip) schemaValue = await updateSchema(username, result.publicContactResult, probe);
          else schemaValue = (await deps.storage.get(schemaKey))[schemaKey];
          // Cache before the cancellation check so a resume never repeats this request.
          result.requestedUserId = userId;
          cache.set(cacheKey, result);
          await storeProfile(username, userId, result);
          if (!active()) throw stopped("Consulta cancelada.", "cancelled");
          return decided(result, schemaValue, false);
        } catch (error) {
          if (error && error.commercialRequestStopped) throw error;
          throw stopped("Não foi possível concluir a consulta de contato. Coleta pausada, sem nova tentativa automática.", "request");
        }
      });
    };
  }
  return { create: create, retryUntil: retryUntil, unsupported: unsupported, readSchema: readSchema, maskEmail: maskEmail,
    saveCooldown: saveCooldown, cooldownLock: cooldownLock, stateSinceKey: "ig_contact_state_since",
    pacingKey: pacingKey, profileCacheKey: profileCacheKey, emailPaths: emailPaths, baseSpacing: baseSpacing, maxSpacing: maxSpacing,
    blockReason: blockReason, routeRefusing: routeRefusing, endpoint: endpoint, cooldownKey: cooldownKey, schemaKey: schemaKey, evidenceKey: evidenceKey,
    omittedProfessionalLimit: omittedProfessionalLimit, withheldProfessionalLimit: withheldProfessionalLimit, refusedLimit: refusedLimit };
});
