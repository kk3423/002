/* PATCHED 14: one ordinary web_profile_info request per profile, serial and
 * fail closed. Every real response is summarised (field names, profile flags,
 * masked email) so the commercial-contact field can be verified, not guessed.
 * A live public commercial contact has not yet been confirmed.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.IGCommercialProfileReader = api;
})(typeof window !== "undefined" ? window : globalThis, function () {
  "use strict";
  var endpoint = "instagram_web_profile_info";
  var cooldownKey = "ig_contact_cooldown_until";
  var schemaKey = "ig_commercial_contact_schema_v14";
  var evidenceKey = "ig_commercial_contact_evidence_v14";
  var lastStartKey = "ig_commercial_web_last_start";
  var lockName = "ig-commercial-profile-read";
  var own = Object.prototype.hasOwnProperty;
  var professionalTypes = ["business", "creator", "professional"];
  // Omission blocks the route only after repeated professional profiles and no
  // response with the field: personal or unknown accounts never count.
  var omittedProfessionalLimit = 3, evidenceLimit = 20, listLimit = 10;
  var flagFields = ["account_type", "is_business_account", "is_professional_account", "is_business",
    "should_show_public_contacts", "business_contact_method", "is_private"];

  function retryUntil(value, now) {
    var raw = String(value == null ? "" : value).trim();
    if (/^\d+(?:\.\d+)?$/.test(raw)) return now + Math.max(10, Number(raw)) * 1000;
    var date = Date.parse(raw);
    return Number.isFinite(date) && date > now ? date : now + 3600000;
  }
  function stopped(message, code, response) {
    var error = new Error(message);
    error.commercialRequestStopped = true;
    error.stopCode = code;
    if (response) error.response = response;
    return error;
  }
  function maskEmail(value) {
    var s = String(value || ""), at = s.indexOf("@");
    return at > 0 ? s.charAt(0) + "***" + s.slice(at) : "";
  }
  function readSchema(value) {
    var schema = { endpoint: endpoint, keysPresent: 0, keysPresentUsers: [], omittedProfessional: [], omittedOther: 0, updatedAt: 0 };
    if (!value || typeof value !== "object" || value.endpoint !== endpoint) return schema;
    schema.keysPresent = Number(value.keysPresent) || 0;
    schema.omittedOther = Number(value.omittedOther) || 0;
    schema.updatedAt = Number(value.updatedAt) || 0;
    ["keysPresentUsers", "omittedProfessional"].forEach(function (key) {
      schema[key] = Array.isArray(value[key]) ? value[key].slice(-listLimit) : [];
    });
    return schema;
  }
  function unsupported(value) {
    var schema = readSchema(value);
    return schema.keysPresent === 0 && schema.omittedProfessional.length >= omittedProfessionalLimit;
  }
  function remember(list, username) {
    return list.indexOf(username) >= 0 ? list : list.concat(username).slice(-listLimit);
  }
  function locate(body) {
    // web_profile_info envelope, as in the extension's ApiProfileInfo config: { data: { user } }.
    var data = body && typeof body === "object" ? body.data : null;
    if (!data || typeof data !== "object" || !own.call(data, "user")) return { known: false, user: null };
    var user = data.user;
    return { known: true, user: user && typeof user === "object" && !Array.isArray(user) ? user : null };
  }
  function create(deps) {
    var cache = new Map();
    function assertOpen(saved, probe) {
      if (Number(saved[cooldownKey]) > deps.now()) {
        var cooldown = stopped("O Instagram está em pausa. Aguarde o horário indicado.", "cooldown");
        cooldown.cooldownUntil = Number(saved[cooldownKey]);
        throw cooldown;
      }
      // A manual one-profile check may re-evaluate the route; the queue may not.
      if (!probe && unsupported(saved[schemaKey])) {
        throw stopped("A consulta web não trouxe o campo de e-mail comercial em perfis profissionais. A fila está interrompida; use a verificação de 1 perfil para reavaliar.", "unsupported");
      }
    }
    function record(entry) {
      return Promise.resolve().then(function () { return deps.storage.get(evidenceKey); }).then(function (saved) {
        var list = saved && Array.isArray(saved[evidenceKey]) ? saved[evidenceKey] : [];
        return deps.storage.set({ [evidenceKey]: [entry].concat(list).slice(0, evidenceLimit) });
      }).catch(function () { /* diagnostics must never change the collection result */ });
    }
    function updateSchema(username, contact) {
      return deps.storage.get(schemaKey).then(function (saved) {
        var schema = readSchema(saved[schemaKey]);
        if (contact.emailFieldReturned) {
          schema.keysPresent += 1;
          schema.keysPresentUsers = remember(schema.keysPresentUsers, username);
        } else if (contact.emailStatus === "omitted" && professionalTypes.indexOf(contact.profileType) >= 0) {
          schema.omittedProfessional = remember(schema.omittedProfessional, username);
        } else {
          schema.omittedOther += 1;
        }
        schema.updatedAt = deps.now();
        return deps.storage.set({ [schemaKey]: schema }).then(function () { return schema; });
      });
    }
    function skip(outcome, entry) {
      entry.outcome = outcome;
      return { contactSkip: true, contactOutcome: outcome, contactEndpoint: endpoint };
    }
    async function fetchProfile(username, userId, entry) {
      var controller = new AbortController();
      var timer = setTimeout(function () { controller.abort(); }, 30000);
      var response, raw;
      try {
        try {
          response = await deps.fetch("https://www.instagram.com/api/v1/users/web_profile_info/?username=" + encodeURIComponent(username), {
            method: "GET", credentials: "include", redirect: "manual", cache: "no-store", signal: controller.signal,
            headers: { Accept: "application/json", "X-IG-App-ID": "936619743392459", "X-Requested-With": "XMLHttpRequest" }
          });
        } catch (err) {
          entry.outcome = "network";
          throw stopped("Falha de rede ou tempo esgotado na consulta de contato. Coleta pausada, sem nova tentativa automática.", "network");
        }
        entry.http = response.status;
        // Not followed: a login or checkpoint redirect is an access failure.
        if (response.type === "opaqueredirect" || (response.status >= 300 && response.status < 400)) {
          entry.outcome = "redirect";
          throw stopped("O Instagram redirecionou a consulta (login ou verificação). Coleta pausada, sem nova tentativa automática.", "redirect", { status: response.status });
        }
        if (response.status === 429) {
          entry.retryAfter = response.headers.get("retry-after");
          var latest = await deps.storage.get(cooldownKey);
          var until = Math.max(Number(latest[cooldownKey]) || 0, retryUntil(entry.retryAfter, deps.now()));
          await deps.storage.set({ [cooldownKey]: until });
          entry.outcome = "rate_limit";
          entry.cooldownUntil = until;
          var limited = stopped("O Instagram limitou as consultas (HTTP 429). Coleta pausada até o horário indicado, sem nova tentativa automática.", "rate_limit", {
            status: 429, headers: { "retry-after": new Date(until).toUTCString() }
          });
          limited.cooldownUntil = until;
          throw limited;
        }
        try { raw = await response.text(); } catch (err) {
          entry.outcome = "network";
          throw stopped("Falha de rede ou tempo esgotado na consulta de contato. Coleta pausada, sem nova tentativa automática.", "network");
        }
      } finally { clearTimeout(timer); }
      var body = null;
      try { body = JSON.parse(raw); } catch (err) { body = null; }
      var message = body && typeof body === "object" && typeof body.message === "string" ? body.message.slice(0, 120) : "";
      if (message) entry.message = message;
      if (response.status === 404) return skip("profile_unavailable", entry);
      if (!response.ok) {
        entry.outcome = "access";
        throw stopped("O Instagram recusou a consulta de contato (HTTP " + response.status + (message ? ": " + message : "") + "). Coleta pausada, sem nova tentativa automática.", "access", { status: response.status });
      }
      if (!body || typeof body !== "object") {
        entry.outcome = "invalid_response";
        throw stopped("O Instagram devolveu uma página em vez de dados (possível login ou verificação). Coleta pausada, sem nova tentativa automática.", "invalid_response", { status: response.status });
      }
      if (body.status === "fail" || body.require_login || (Array.isArray(body.errors) && body.errors.length)) {
        entry.outcome = "access";
        throw stopped("O Instagram não autorizou a consulta de perfil" + (message ? " (" + message + ")" : "") + ". Coleta pausada, sem nova tentativa automática.", "access", { status: response.status });
      }
      var located = locate(body);
      if (!located.known) {
        entry.outcome = "unexpected_response";
        throw stopped("A resposta do Instagram veio num formato desconhecido. Coleta pausada, sem nova tentativa automática.", "unexpected_response", { status: response.status });
      }
      // Missing or renamed profiles are per-row results, not session failures.
      if (!located.user) return skip("profile_unavailable", entry);
      var user = located.user;
      var returnedName = String(user.username || "").toLowerCase(), returnedId = String(user.pk || user.id || "");
      if (returnedName !== username || (userId && returnedId && returnedId !== userId)) {
        entry.returnedUsername = returnedName.slice(0, 40);
        return skip("identity_mismatch", entry);
      }
      var detail = deps.contacts.toDetailResponse(user, username), contact = detail.publicContactResult, flags = {};
      flagFields.forEach(function (key) { if (own.call(user, key)) flags[key] = user[key]; });
      entry.outcome = contact.emailStatus;
      entry.profileType = contact.profileType;
      entry.keys = contact.emailKeys;
      entry.flags = flags;
      entry.userKeys = Object.keys(user).sort().slice(0, 300);
      entry.email = maskEmail(contact.email);
      detail.contactEndpoint = endpoint;
      detail.contactOutcome = contact.emailStatus;
      detail.commercialContactFieldReturned = contact.emailFieldReturned;
      return detail;
    }
    function decided(result, schemaValue, fromCache) {
      var copy = Object.assign({}, result);
      copy.commercialSchemaUnsupported = unsupported(schemaValue);
      copy.commercialSchema = readSchema(schemaValue);
      if (fromCache) copy.fromCache = true;
      return copy;
    }
    return async function read(userId, username, isCurrent, options) {
      var probe = !!(options && options.probe);
      username = String(username || "").trim().replace(/^@/, "").toLowerCase();
      userId = String(userId || "");
      if (!/^[a-z0-9_](?:[a-z0-9_.]{0,28}[a-z0-9_])?$/.test(username)) {
        throw stopped("Nome de perfil inválido. A consulta foi interrompida.", "identity");
      }
      if (!deps.locks || typeof deps.locks.request !== "function") {
        throw stopped("Não foi possível controlar a fila de consultas. Coleta pausada.", "lock");
      }
      var active = function () { return !isCurrent || isCurrent(); };
      var cacheKey = userId + ":" + username;
      return deps.locks.request(lockName, async function () {
        try {
          if (!active()) throw stopped("Consulta cancelada.", "cancelled");
          var saved = await deps.storage.get([cooldownKey, schemaKey, lastStartKey]);
          assertOpen(saved, probe);
          if (cache.has(cacheKey)) return decided(cache.get(cacheKey), saved[schemaKey], true);
          var delay = Math.max(0, Number(saved[lastStartKey]) + 10000 - deps.now());
          if (delay) await deps.wait(delay);
          // Another dashboard can save a cooldown or a decision while this reader waits.
          saved = await deps.storage.get([cooldownKey, schemaKey]);
          assertOpen(saved, probe);
          if (!active()) throw stopped("Consulta cancelada.", "cancelled");
          await deps.storage.set({ [lastStartKey]: deps.now() });
          if (!active()) throw stopped("Consulta cancelada.", "cancelled");
          var entry = { at: deps.now(), endpoint: endpoint, username: username, probe: probe, http: null, outcome: "" };
          var result;
          try { result = await fetchProfile(username, userId, entry); }
          finally { await record(entry); }
          var schemaValue = saved[schemaKey];
          if (!result.contactSkip) schemaValue = await updateSchema(username, result.publicContactResult);
          // Cache before the cancellation check so a resume never repeats this request.
          cache.set(cacheKey, result);
          if (!active()) throw stopped("Consulta cancelada.", "cancelled");
          return decided(result, schemaValue, false);
        } catch (error) {
          if (error && error.commercialRequestStopped) throw error;
          throw stopped("Não foi possível concluir a consulta de contato. Coleta pausada, sem nova tentativa automática.", "request");
        }
      });
    };
  }
  return { create: create, retryUntil: retryUntil, unsupported: unsupported, readSchema: readSchema, maskEmail: maskEmail,
    endpoint: endpoint, cooldownKey: cooldownKey, schemaKey: schemaKey, evidenceKey: evidenceKey,
    omittedProfessionalLimit: omittedProfessionalLimit };
});
